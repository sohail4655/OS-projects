/*
 * CS354: Shell project
 *
 * Template file.
 * You will need to add more code here to execute the command table.
 *
 * NOTE: You are responsible for fixing any bugs this code may have!
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "command.h"
#include <time.h>
SimpleCommand::SimpleCommand()
{
	// Creat available space for 5 arguments
	_numberOfAvailableArguments = 10;
	_numberOfArguments = 0;
	_arguments = (char **)malloc(_numberOfAvailableArguments * sizeof(char *));
}

void SimpleCommand::insertArgument(char *argument)
{
	if (_numberOfAvailableArguments == _numberOfArguments + 1)
	{
		// Double the available space
		_numberOfAvailableArguments *= 2;
		_arguments = (char **)realloc(_arguments,
									  _numberOfAvailableArguments * sizeof(char *));
	}

	_arguments[_numberOfArguments] = argument;

	// Add NULL argument at the end
	_arguments[_numberOfArguments + 1] = NULL;

	_numberOfArguments++;
}

Command::Command()
{
	// Create available space for one simple command
	_numberOfAvailableSimpleCommands = 1;
	_simpleCommands = (SimpleCommand **)
		malloc(_numberOfSimpleCommands * sizeof(SimpleCommand *));

	_numberOfSimpleCommands = 0;
	_outFile = 0;
	_inputFile = 0;
	_errFile = 0;
	_background = 0;
	_overwrite = 0;
}

void Command::insertSimpleCommand(SimpleCommand *simpleCommand)
{
	if (_numberOfAvailableSimpleCommands == _numberOfSimpleCommands)
	{
		_numberOfAvailableSimpleCommands *= 2;
		_simpleCommands = (SimpleCommand **)realloc(_simpleCommands,
													_numberOfAvailableSimpleCommands * sizeof(SimpleCommand *));
	}

	_simpleCommands[_numberOfSimpleCommands] = simpleCommand;
	_numberOfSimpleCommands++;
}

void Command::clear()
{
	for (int i = 0; i < _numberOfSimpleCommands; i++)
	{
		for (int j = 0; j < _simpleCommands[i]->_numberOfArguments; j++)
		{
			free(_simpleCommands[i]->_arguments[j]);
		}

		free(_simpleCommands[i]->_arguments);
		free(_simpleCommands[i]);
	}

	if (_outFile)
	{
		free(_outFile);
	}

	if (_inputFile)
	{
		free(_inputFile);
	}

	if (_errFile)
	{
		free(_errFile);
	}

	_numberOfSimpleCommands = 0;
	_outFile = 0;
	_inputFile = 0;
	_errFile = 0;
	_background = 0;
	_overwrite = 0;
}

void Command::print()
{
	printf("\n\n");
	printf("              COMMAND TABLE                \n");
	printf("\n");
	printf("  #   Simple Commands\n");
	printf("  --- ----------------------------------------------------------\n");

	for (int i = 0; i < _numberOfSimpleCommands; i++)
	{
		printf("  %-3d ", i);
		for (int j = 0; j < _simpleCommands[i]->_numberOfArguments; j++)
		{
			printf("\"%s\" \t", _simpleCommands[i]->_arguments[j]);
		}
		printf("\n");
	}

	printf("\n\n");
	printf("  Output       Input        Error        Background\n");
	printf("  ------------ ------------ ------------ ------------\n");
	printf("  %-12s %-12s %-12s %-12s\n", _outFile ? _outFile : "default",
		   _inputFile ? _inputFile : "default", _errFile ? _errFile : "default",
		   _background ? "YES" : "NO");
	printf("\n\n");
}

void Command::execute()
{
	// Don't do anything if there are no simple commands
	if (_numberOfSimpleCommands == 0)
	{
		prompt();
		return;
	}

	// Print contents of Command data structure
	print();

	int defaultin = dup(0);	 // Default file Descriptor for stdin
	int defaultout = dup(1); // Default file Descriptor for stdout
	int defaulterr = dup(2); // Default file Descriptor for stderr
	int inFile, outputFile, errorFile;

	if (_errFile != 0)
	{
		errorFile = open(_errFile, O_WRONLY | O_CREAT, 0777);
		dup2(errorFile, 2);
		close(errorFile);
	}
	else
	{
		dup2(defaulterr, 2);
		close(defaulterr);
	}
	// int pipeQ[_numberOfSimpleCommands][2];
	int pipeQ[2];
	if (pipe(pipeQ) == -1)
	{
		perror("Pipe");
		exit(2);
	}
	for (int i = 0; i < _numberOfSimpleCommands; i++)
	{
		// dup2(inFile, 0);
		// close(inFile);
		if (i == 0)
		{
			if (_inputFile != 0)
			{
				inFile = open(_inputFile, O_RDONLY, 0777);

				if (inFile < 0)
				{
					perror("Not Found");
					exit(2);
				}
				else
				{
					dup2(inFile, 0);
					close(inFile);
				}
			}
			else
			{
				dup2(defaultin, 0);
				close(defaultin);
			}
		}
		else if (i != 0)
		{
			dup2(pipeQ[0], 0);
			close(pipeQ[0]);
			close(pipeQ[1]);
			if (pipe(pipeQ) == -1)
			{
				perror("Pipe");
				exit(2);
			}
		}

		if (i == _numberOfSimpleCommands - 1)
		{
			if (_outFile != 0)
			{
				if (_overwrite == 0)
				{
					outputFile = creat(_outFile, 0666);
				}
				else
				{
					outputFile = open(_outFile, O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);
				}
				if (outputFile < 0)
				{
					// int outputFile = creat(_outFile, 0666);
					perror("ls : create outfile");
					exit(2);
				}
				// Redirect output to the created utfile instead off printing to stdout
				dup2(outputFile, 1);
				close(outputFile);
			}
			else
			{
				dup2(defaultout, 1);
				close(defaultout);
			}
		}
		else if (i != _numberOfSimpleCommands - 1)
		{
			/*
			if (_numberOfSimpleCommands > 1)

			{
				if (i == 0)
				{
					pipe(pipeQ[i]);
					outputFile = pipeQ[i][1];
					// inFile = pipeQ[i][0];
					dup2(outputFile, 1);
					// dup2(inFile, 0);
					close(outputFile);
				}
				else if (i == _numberOfSimpleCommands - 1)
				{
					pipe(pipeQ[i]);
					// outputFile = pipeQ[i][1];
					inFile = pipeQ[i][0];
					// dup2(outputFile, 1);
					dup2(inFile, 0);
					// close(inFile);
				}
				else
				{
					pipe(pipeQ[i]);
					outputFile = pipeQ[i][1];
					inFile = pipeQ[i][0];
					dup2(outputFile, 1);
					dup2(inFile, 0);
					// close(outputFile);
					// close(inFile);
				}
			}
			*/
			dup2(pipeQ[1], 1);
			close(pipeQ[1]);
		}
		
		int pid = fork();
		if (pid < 0)
		{
			perror("Failed\n");
			exit(2);
		}
		else if (pid == 0)
		{/*
			close(pipeQ[0]);
			close(pipeQ[1]);
			close(outputFile);
			close(inFile);
			close(errorFile);
			close(defaultin);
			close(defaultout);
			close(defaulterr);*/
			execvp(_simpleCommands[i]->_arguments[0], _simpleCommands[i]->_arguments);
			 //return;
			perror("execvp");
			exit(0);
		}
		else
		{
			dup2(defaultin, 0);
			dup2(defaultout, 1);
			dup2(defaulterr, 2);
			//close(pipeQ[0]);
			//close(pipeQ[1]);

			// Close file descriptors that are not needed
			if (!_background)
			{
				waitpid(pid, 0, 0);
			}
			// close(outputFile);
			// close(inFile);
			// close(errorFile);
		}
	}


	dup2(defaultin, 0);
	dup2(defaultout, 1);
	dup2(defaulterr, 2);

	
	if (_inputFile)
	{
		close(inFile);
	}
	if (_outFile)
	{
		close(outputFile);
	}
	if (_errFile)
	{
		close(errorFile);
	}

	clear();
	// Print new prompt
	prompt();
}

// Shell implementation

void Command::prompt()
{
	printf("myshell:> ");
	fflush(stdout);
}

Command Command::_currentCommand;
SimpleCommand *Command::_currentSimpleCommand;

int yyparse(void);

void handleCtrlC(int signum)
{
	printf("\nCtrl+C is ignored.\n");
	Command::_currentCommand.clear();
	Command::_currentCommand.prompt();
}

void handleChild(int signum)
{
	time_t t;
	char time1[35];
	t = time(NULL);
	strcpy(time1, ctime(&t));
	char str[] = "Process Terminated at ";
	strcat(str, time1);
	strcat(str, "\n");
	int outputFile = open("Logs.txt", O_WRONLY | O_CREAT | O_APPEND, S_IRUSR | S_IWUSR);
	write(outputFile, str, strlen(str));
	// sleep(3);
	close(outputFile);
}

int main()
{
	signal(SIGINT, handleCtrlC);
	signal(SIGCHLD, handleChild);
	Command::_currentCommand.prompt();
	yyparse();
	return 0;
}
