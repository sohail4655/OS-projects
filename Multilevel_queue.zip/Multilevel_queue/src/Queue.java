public class Queue {
    private Process queue[];
    private int head=0;
    private int tail=0;
    private int capcity=0;
    private int size=0;



    public Queue(int capcity) {
        this.capcity = capcity;
        this.queue = new Process[capcity];
    }
    boolean cleared(){
        return this.size==0?true:false;
    }
    boolean saturated(){
        return this.size==this.capcity?true:false;
    }

    public int getSize() {
        return size;
    }

    void enqueue(Process value){
        if(this.saturated()){
            return;
        }
        else {
            this.queue[this.tail]=value;
            this.tail=(this.tail+1)%this.capcity;
            this.size+=1;
        }
    }
    Process dequeue(){
        if(this.cleared()){
         return null;
        }
        Process out=this.queue[this.head];
        this.head=(this.head+1)%this.capcity;
        this.size-=1;
        return out;
    }
    Process peek(){
        if(this.cleared()){
            return null;
        }
        return this.queue[this.head];
    }
    void show_queue(){
        if(this.cleared()){
            System.out.println("Queue is empty now !!!!");
            return;
        }
        for (int i = 0; i < this.size; i++) {
            System.out.println(this.queue[i].id+" : "+this.queue[i].burst);
        }
        System.out.println("");
    }
}
