import java.util.Random;

public class Process {
    int id;
    int burst;

    public Process(int id) {
        this.id=id;
        Random rand = new Random();
        int burst = rand.nextInt(100-1 + 1) + 1;
        this.burst = burst;
    }
}
