import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.ArrayList; // import the ArrayList class

public class Main {
    static int id=1;
    static ArrayList<Process> Finished = new ArrayList<Process>();
    static ArrayList<Process> P = new ArrayList<Process>();
    static void print(Queue q){
        for (int i = 0; i < q.getSize(); i++) {

            Process a=q.dequeue();
            if(a.burst<=0){
                System.out.println("Process "+a.id +" : finished !!");
            }
            else {
            System.out.println("Process "+a.id +" : "+a.burst);
            q.enqueue(a);}

        }

    }
    static Process Queue1_RR(Process p,Queue RR1,Queue RR2,Queue fcfs){
        System.out.println("Queue 1 Round Robin ------------------------------------------------------------");

        RR1.enqueue(p);
        int size= RR1.getSize();
        if(size==0){
            System.out.println("Queue 1 Round Robin is empty !!");
            return null;}
        if(p.id==-1){
            Process m=RR1.dequeue();
            for (int i = 0; i < 8; i++) {
                m.burst= m.burst-1;
                if(m.burst==0)
                    break;
            }
            RR2.enqueue(m);
            return m;
        }
        for (int i = 0; i < size; i++) {
            Process x=RR1.dequeue();
            System.out.print("Process ("+x.id +"): "+x.burst+"  ,  ");
            if(!(x.burst==0))
            RR1.enqueue(x);}
        System.out.println("");
         Process a = null;
         if(!RR1.cleared())
              a=RR1.dequeue();

        for (int i = 0; i < 8; i++) {
            a.burst= a.burst-1;
            if(a.burst==0)
                break;
        }
        if(a.burst==0)
            return a;
        else {
            RR2.enqueue(a);
            return a;
        }
    }
    static Process Queue1_RR_finished(Queue RR1,Queue RR2,Queue fcfs){
        System.out.println("Queue 1 Round Robin ------------------------------------------------------------");
        int size= RR1.getSize();
        if(size==0){
            System.out.println("Queue 1 Round Robin is empty !!");
            return null;}
        for (int i = 0; i < size; i++) {
            Process x=RR1.dequeue();
            System.out.print("Process ("+x.id +"): "+x.burst+"  ,  ");
            if(!(x.burst==0))
                RR1.enqueue(x);}
        System.out.println("");
        Process a = null;
        if(!RR1.cleared())
            a=RR1.dequeue();
        for (int i = 0; i < 8; i++) {
            a.burst= a.burst-1;
            if(a.burst==0)
                break;
        }
        if(a.burst==0)
            return a;
        else {
            RR2.enqueue(a);
            return a;
        }
    }
    static Process Queue2_RR(Queue RR1,Queue RR2,Queue fcfs){
        System.out.println("Queue 2 Round Robin ------------------------------------------------------------");
        int size= RR2.getSize();
        if(size==0){
            System.out.println("Queue 2 Round Robin is empty !!");
            return null;}
        for (int i = 0; i < size; i++) {
            Process x=RR2.dequeue();
            System.out.print("Process ("+x.id +"): "+x.burst+"  ,  ");
            RR2.enqueue(x);}
        System.out.println("");
        Random rand = new Random();
        Process a=RR2.dequeue();
        for (int i = 0; i < 16; i++) {
            a.burst= a.burst-1;
            if(a.burst==0)
                break;
        }
        if(a.burst==0)
            return a;
        else {
            int promote = rand.nextInt(1000);
            promote = promote % 2;
            if(promote==0){
                P.add(a);
                System.out.println("Process ("+a.id+") returned back to Queue 1 RR !!!" );
                for (int i = 0; i < P.size(); i++) {
                    System.out.println("("+P.get(i).id+")   "+P.get(i).burst);
                }
                return a;
            }
            else {fcfs.enqueue(a);
                  return a;
            }
        }
    }
    static Process Queue3_FcFs(Queue RR1,Queue RR2,Queue fcfs){
        System.out.println("Queue 3 First come First served ------------------------------------------------------------");
        int size=fcfs.getSize();
        if(size==0){
            System.out.println("Queue 3 FCFS is empty !!");
            return null;}
        for (int i = 0; i < size; i++) {
            Process x=fcfs.dequeue();
            System.out.print("Process ("+x.id +"): "+x.burst+"  ,  ");
            if(!(x.burst==0))
            fcfs.enqueue(x);
            else{
                Finished.add(x);
            }
        }

        System.out.println("");

        Process a=fcfs.dequeue();
        while (a.burst>0){
            a.burst=a.burst-1;
        }
        return a;
    }
    static void Manage_Queues(ArrayList<Process> P){
        Queue RR1=new Queue(10);
        Queue RR2=new Queue(20);
        Queue FcFs=new Queue(30);
        Process out;
        for (int i = 0; i < 10; i++) {
            Process now=P.get(0);
            RR1.enqueue(now);
            P.remove(0);
        }
        while (!(RR1.cleared() && RR2.cleared() && FcFs.cleared() && P.size()==0)){
            for (int i = 0; i < 5; i++) {
                if(P.size()>0){
                    Process now;
                    if(RR2.saturated()){
                        break;
                    }
                 if(!RR1.saturated()){
                     now=P.get(0);
                    P.remove(0);}

                else {
                    now=new Process(-1);
                 }
                out=Queue1_RR(now,RR1,RR2,FcFs);
                if(out != null){
                if(out.burst==0){
                    System.out.println("-----------------------     -----------------------     ----------------------");
                    System.out.println("Process ("+out.id +") : finished !!");
                    Finished.add(out);
                }}}
                else {
                        out=Queue1_RR_finished(RR1,RR2,FcFs);
                        if(out == null){}
                        else if(out.burst==0){
                            System.out.println("****************************************************************************");
                            System.out.println("");
                            System.out.println("Process "+out.id +" : finished !!");
                            Finished.add(out);
                            System.out.println("");
                            System.out.println("****************************************************************************");
                        }
            }
                if(RR2.saturated()){
                    break;
                }
            }
            System.out.println("");
            System.out.println("");
            System.out.println("");
            for (int i = 0; i < 3; i++) {
                out=Queue2_RR(RR1,RR2,FcFs);
                if(out != null){
                if(out.burst==0){
                    System.out.println("****************************************************************************");
                    System.out.println("");
                    System.out.println("Process "+out.id +" : finished !!");
                    Finished.add(out);
                    System.out.println("");
                    System.out.println("****************************************************************************");
                }  }
            }
            System.out.println("");
            System.out.println("");
            System.out.println("");
            for (int i = 0; i < 2; i++) {
                out=Queue3_FcFs(RR1,RR2,FcFs);
                if(out != null){
                if(out.burst==0){
                    System.out.println("****************************************************************************");
                    System.out.println("");
                    System.out.println("Process "+out.id +" : finished !!");
                    Finished.add(out);
                    System.out.println("");
                    System.out.println("****************************************************************************");
                } }
            }
            System.out.println("");
            System.out.println("");
            System.out.println("");
        }
    }
    public static void main(String[] args) throws InterruptedException {
        System.out.println("How many processes do you want to be created ?");
        Scanner scan=new Scanner(System.in);
        int no_of_processes= scan.nextInt();
        for (int i = 0; i < no_of_processes; i++) {
            P.add(new Process(id));
            System.out.print("Process ("+P.get(i).id +"): "+P.get(i).burst+"  ,  ");
            id=id+1;

        }
        // Manage queues contain 3 loops 5 , 3 , 2 to divide cpu time Queue1 : 50% ,  Queue2 : 30% ,Queue3 : 20%
        Manage_Queues(P);
        System.out.println("Finished processes by order ");
        ArrayList<Integer> ss=new ArrayList<Integer>();
        for (int i = 0; i < Finished.size(); i++) {
            System.out.print(i+1+"- ");
            System.out.println("Process " + Finished.get(i).id);
            ss.add(Finished.get(i).id);
        }

    }
}

