#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <signal.h>
#define KRED  "\x1B[31m"
#define KGRN  "\x1B[32m"
#define KYEL  "\x1B[33m"
#define KBLU  "\x1B[34m"
#define KSSS  "\x1B[35m"
#define KNRM  "\x1B[0m"
#define Queue_size 5
typedef struct
{
    int *item;
    int head;
    int tail;
    int size;
    int capcity ;
} Queue;
Queue *init (int x)
{
    Queue *q=malloc(24);
    q->item = malloc(4*x);
    q->head=0;
    q->tail=0;
    q->size=0;
    q->capcity=x;
}
int isfull(Queue *q)
{
    return q->size==q->capcity;
}
int isempty(Queue *q)
{
    return q->size==0;
}
void enq(Queue *q,int x)
{
    if(isfull(q))return;
    q->item[q->tail++]=x;
    q->tail=(q->tail)%q->capcity;
    q->size++;
}
int deq(Queue *q)
{
    if(isempty(q))return -1;
    q->size--;
    int x=q->item[q->head];
    q->head=(q->head + 1)%q->capcity;
    return x ;
}
int peek(Queue *q)
{
    return q->item[q->head];
}
void destruct(Queue *q)
{
    free(q->item);
    free(q);
}
void display(Queue *q)
{
    int x;
    Queue *s=init(q->capcity);
    while(!isempty(q))
    {
        x=deq(q);
        enq(s,x);
        printf("%d ",x);
    }
    printf("\n");
    while(!isempty(s))
        enq(q,deq(s));
}

sem_t mutex,mutex2,full2,empty2;
Queue *global_queue;
int k=0;
int global=0;
void* counter_thread(void *args)
{
    int thread_no = *(int *)args;
    printf("%s Produuuuuuuuce %d   \n",KRED,thread_no);

	for (int i =1; i<=4;i++){
        printf("%s*********************** Producer number %d...\n",KRED,*(int *)args);
        printf("%s COUNTER received message    \n",KYEL);
		//wait
		printf("%sCOUNTER %d: (global %d) Trying to Enter critical section and adding to global..\n",KYEL,i,global);
		sem_wait(&mutex);
		printf("%sCOUNTER %d: (global %d) Entered critical section..\n",KYEL,i,global);
		//critical section
		global++;

		//signal
		printf("%sCOUNTER %d: (global %d) finished critical section ...\n",KYEL,i,global);
		sem_post(&mutex);
		//sleep after
		sleep((rand() % 3) + (thread_no%3));
	}
}
void* monitoring(void *args)
{
  int value;
	for (int i =1; i<=8;i++){
		printf("%sMONITORING %d:  Waiting to read on empty Sem value is  ...\n",KGRN,i);
		//wait
		sem_wait(&empty2);
		sem_wait(&mutex);
		printf("%sMONITORING %d:  Entered critical section..\n",KGRN,i);
		//critical section
		value=global;
		printf("%sMONITORING %d:  readed value %d  ....\n",KGRN,i,value);
		 global=0;

		//printf("%sCONSUMER: Just Exiting critical section...\n",KGRN);
		//signal
		printf("%sMONITORING %d:  Signal the empty the value before signal is %d...\n",KGRN,i);
        sem_post(&mutex);
		printf("%sMONITORING %d:  Trying to Enter critical section..\n",KGRN,i);
		sem_wait(&mutex2);
		printf("%sMONITORING %d:  Entered critical section..\n",KGRN,i);
		//critical section
		if(!isfull(global_queue) && value != 0){
        printf("%sMONITORING %d:  put at position %d  ....\n",KGRN,i,k%Queue_size);
		enq(global_queue,value);
		k++;}
		else if(!isfull(global_queue) && value == 0){
         enq(global_queue,value);
		}
        else{
            printf("%sMONITORING %d:  Full Buffer !!!\n",KGRN,i);
        }
		//signal
		printf("%sMONITORING %d:  Signal the full Sem  ...\n",KGRN,i);
		sem_post(&mutex2);
		sem_post(&full2);
		//sleep after
		sleep((rand() % 3) + 1);
	}
}

void* collector_thread(void *args)
{

	for (int i =1; i<=8 ;i++){
		int sem_value;
		sem_getvalue(&full2,&sem_value);
		printf("%sCOLLECTER %d: Waiting on full Sem value is %d ...\n",KSSS,i, sem_value);
		//wait
		sem_wait(&full2);
		printf("%sCOLLECTER %d: Trying to Enter critical section..\n",KSSS,i);
		sem_wait(&mutex2);
		printf("%sCOLLECTER %d: Entered critical section..\n",KSSS,i);
		//critical section

		 int x=deq(global_queue);
		 if(x==0)
        printf("%sCOLLECTER %d: Nothing in the buffer..\n",KSSS,i);
         else
        printf("%shere       %d        \n",KBLU,x);
        sem_post(&mutex2);
		sem_post(&empty2);
		//sleep after
		sleep(2);
	}

}

void intHandler(int dummy) {
	// set the noramal color back
    printf("%sExit\n", KNRM);
	// Destroy the semaphore
	sem_destroy(&mutex);
	sem_destroy(&mutex2);
	sem_destroy(&full2);
	sem_destroy(&empty2);
	exit(0);
}

int main()
{
	signal(SIGINT, intHandler);
    int n;
    global_queue=init(Queue_size);

	printf("how many producers do you want ?\n");
	scanf("%d",&n);
	sem_init(&mutex, 0, 1);

	sem_init(&mutex2, 0, 1);
	sem_init(&full2, 0, 0);
	sem_init(&empty2, 0, 1);

	pthread_t threads[n+1];
	pthread_t t1,t2;
	pthread_create(&t1,NULL,monitoring,NULL);
	pthread_create(&t2,NULL,collector_thread,NULL);
	int arr[n+1];
	for(int i=1;i<=n;i++){
     arr[i]=i;
     pthread_create(&threads[i],NULL,counter_thread,(void *)&arr[i]);
	}

		pthread_join(t1,NULL);
	pthread_join(t2,NULL);

	for(int i=1;i<=n;i++){
     pthread_join(threads[i],NULL);
	}

	sem_destroy(&mutex);
	sem_destroy(&mutex2);
	sem_destroy(&full2);
	sem_destroy(&empty2);
	printf("%sExit\n", KNRM);


	return 0;
}
